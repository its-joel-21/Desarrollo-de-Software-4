using BackendComun;

await ApiHost.RunAsync(args, "Linux", 5002);
