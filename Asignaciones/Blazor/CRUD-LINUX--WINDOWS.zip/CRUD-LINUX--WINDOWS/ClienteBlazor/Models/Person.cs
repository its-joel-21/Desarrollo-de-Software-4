using System.ComponentModel.DataAnnotations;

namespace ClienteBlazor.Models;

public sealed record Person(int Id, string Name, int Age);

public sealed class PersonForm
{
    [Required(ErrorMessage = "Escribe el nombre.")]
    [StringLength(100, ErrorMessage = "El nombre no puede superar los 100 caracteres.")]
    public string Name { get; set; } = "";

    [Required(ErrorMessage = "Escribe la edad.")]
    [Range(0, 120, ErrorMessage = "La edad debe estar entre 0 y 120.")]
    public int? Age { get; set; }
}

public sealed record ApiHealth(string Status, string Backend, string Os, string Storage);
