using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using ClienteBlazor.Models;

namespace ClienteBlazor.Services;

public sealed class PeopleApi(IHttpClientFactory clients, IConfiguration configuration)
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);
    private readonly string? accessHostname = configuration["CloudflareAccess:Hostname"];
    private readonly string? accessClientId = configuration["CloudflareAccess:ClientId"];
    private readonly string? accessClientSecret = configuration["CloudflareAccess:ClientSecret"];

    private HttpClient Create(string baseUrl)
    {
        var normalizedUrl = baseUrl.Trim();
        if (!normalizedUrl.Contains("://", StringComparison.Ordinal))
            normalizedUrl = $"https://{normalizedUrl}";

        if (!Uri.TryCreate(normalizedUrl, UriKind.Absolute, out var uri) ||
            (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps) ||
            uri.AbsolutePath != "/" || !string.IsNullOrEmpty(uri.Query) || !string.IsNullOrEmpty(uri.Fragment))
            throw new ArgumentException("Escribe el host raíz de la API, por ejemplo api.aonis.dev o http://127.0.0.1:5002/");

        var client = clients.CreateClient();
        client.BaseAddress = uri;
        client.Timeout = TimeSpan.FromSeconds(12);

        // Cloudflare Access service credentials are only sent to the exact configured HTTPS host.
        if (!string.IsNullOrWhiteSpace(accessHostname) &&
            string.Equals(uri.IdnHost, accessHostname.Trim().TrimEnd('.'), StringComparison.OrdinalIgnoreCase))
        {
            if (!uri.Scheme.Equals(Uri.UriSchemeHttps, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("La API de Cloudflare Access debe usar HTTPS.");

            if (string.IsNullOrWhiteSpace(accessClientId) || string.IsNullOrWhiteSpace(accessClientSecret))
                throw new InvalidOperationException("Falta configurar el Client ID y Client Secret de Cloudflare Access en los secretos locales de ClienteBlazor.");

            client.DefaultRequestHeaders.Add("CF-Access-Client-Id", accessClientId);
            client.DefaultRequestHeaders.Add("CF-Access-Client-Secret", accessClientSecret);
        }

        return client;
    }

    public async Task<ApiHealth> CheckAsync(string baseUrl, string expectedBackend, CancellationToken cancellationToken = default)
    {
        using var client = Create(baseUrl);
        var health = await client.GetFromJsonAsync<ApiHealth>("api/health", JsonOptions, cancellationToken)
            ?? throw new InvalidOperationException("La API devolvió una respuesta vacía.");
        if (health.Status != "ok" || !string.Equals(health.Backend, expectedBackend, StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException($"La URL respondió como {health.Backend}, no como {expectedBackend}.");
        return health;
    }

    public async Task<IReadOnlyList<Person>> GetAsync(string baseUrl, CancellationToken cancellationToken = default)
    {
        using var client = Create(baseUrl);
        return await client.GetFromJsonAsync<List<Person>>("api/people", JsonOptions, cancellationToken) ?? [];
    }

    public async Task SaveAsync(string baseUrl, int? id, PersonForm form, CancellationToken cancellationToken = default)
    {
        using var client = Create(baseUrl);
        using var response = id is null
            ? await client.PostAsJsonAsync("api/people", new { name = form.Name.Trim(), age = form.Age }, JsonOptions, cancellationToken)
            : await client.PutAsJsonAsync($"api/people/{id}", new { name = form.Name.Trim(), age = form.Age }, JsonOptions, cancellationToken);
        await EnsureSuccessAsync(response, cancellationToken);
    }

    public async Task DeleteAsync(string baseUrl, int id, CancellationToken cancellationToken = default)
    {
        using var client = Create(baseUrl);
        using var response = await client.DeleteAsync($"api/people/{id}", cancellationToken);
        await EnsureSuccessAsync(response, cancellationToken);
    }

    private static async Task EnsureSuccessAsync(HttpResponseMessage response, CancellationToken cancellationToken)
    {
        if (response.IsSuccessStatusCode) return;
        var detail = await response.Content.ReadAsStringAsync(cancellationToken);
        if (detail.Length > 700) detail = detail[..700];
        throw response.StatusCode == HttpStatusCode.NotFound
            ? new InvalidOperationException("Ese registro ya no existe. Actualiza la lista.")
            : new InvalidOperationException($"La API respondió HTTP {(int)response.StatusCode}. {detail}");
    }
}
