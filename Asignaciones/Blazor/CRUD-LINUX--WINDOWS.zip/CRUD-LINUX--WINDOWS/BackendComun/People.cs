namespace BackendComun;

public sealed record People(int Id, string Name, int Age);
public sealed record PeopleInput(string? Name, int? Age)
{
    public Dictionary<string, string[]> Validate()
    {
        var errors = new Dictionary<string, string[]>();
        if (string.IsNullOrWhiteSpace(Name) || Name.Trim().Length > 100)
            errors["name"] = ["Escriba un nombre de 1 a 100 caracteres."];
        if (Age is null or < 0 or > 120)
            errors["age"] = ["Escriba una edad entera entre 0 y 120."];
        return errors;
    }
}
