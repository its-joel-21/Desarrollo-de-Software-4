using System.Runtime.InteropServices;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Npgsql;

namespace BackendComun;

public static class ApiHost
{
    public static async Task RunAsync(string[] args, string backend, int defaultPort)
    {
        var builder = WebApplication.CreateBuilder(args);
        if (string.IsNullOrWhiteSpace(builder.Configuration["urls"]))
            builder.WebHost.UseSetting("urls", $"http://127.0.0.1:{defaultPort}");

        string? connectionString = builder.Configuration.GetConnectionString("People");
        if (string.IsNullOrWhiteSpace(connectionString))
        {
            var password = builder.Configuration["Postgres:Password"];
            if (string.IsNullOrWhiteSpace(password))
                throw new InvalidOperationException("Falta Postgres:Password. Configure Postgres__Password o use los scripts de inicio y el archivo .env. Consulte docs/TUTORIAL.md.");
            connectionString = new NpgsqlConnectionStringBuilder
            {
                Host = builder.Configuration["Postgres:Host"] ?? "127.0.0.1",
                Port = builder.Configuration.GetValue("Postgres:Port", 5432),
                Database = builder.Configuration["Postgres:Database"] ?? "crud_personas",
                Username = builder.Configuration["Postgres:Username"] ?? "crud_app",
                Password = password,
                SslMode = Enum.Parse<SslMode>(builder.Configuration["Postgres:SslMode"] ?? "Prefer", true),
                MaxPoolSize = 20,
                Timeout = 10,
                CommandTimeout = 30
            }.ConnectionString;
        }

        builder.Services.AddSingleton(_ => NpgsqlDataSource.Create(connectionString));
        builder.Services.AddSingleton<PeopleRepository>();
        builder.Services.AddProblemDetails();
        var app = builder.Build();
        app.UseExceptionHandler(handler => handler.Run(async context =>
        {
            var error = context.Features.Get<IExceptionHandlerFeature>()?.Error;
            app.Logger.LogError(error, "Error procesando la petición REST.");
            await Results.Problem(title: "El servidor no pudo completar la operación.",
                detail: "Revise el registro del backend y la conexión con su base de datos.", statusCode: 500).ExecuteAsync(context);
        }));
        app.MapGet("/api/health", async (PeopleRepository db) =>
        {
            await db.CheckAsync();
            return Results.Ok(new { status = "ok", backend, os = RuntimeInformation.OSDescription, storage = db.Provider });
        });
        app.MapGet("/api/people", async (string? name, PeopleRepository db) => Results.Ok(await db.GetAsync(name)));
        app.MapGet("/api/people/{id:int}", async (int id, PeopleRepository db) =>
        {
            var person = await db.GetByIdAsync(id);
            return person is null ? Results.NotFound() : Results.Ok(person);
        });
        app.MapPost("/api/people", async (PeopleInput input, PeopleRepository db) =>
        {
            var errors = input.Validate();
            if (errors.Count > 0) return Results.ValidationProblem(errors);
            var person = await db.AddAsync(input);
            return Results.Created($"/api/people/{person.Id}", person);
        });
        app.MapPut("/api/people/{id:int}", async (int id, PeopleInput input, PeopleRepository db) =>
        {
            var errors = input.Validate();
            if (errors.Count > 0) return Results.ValidationProblem(errors);
            return await db.UpdateAsync(id, input) ? Results.NoContent() : Results.NotFound();
        });
        app.MapDelete("/api/people/{id:int}", async (int id, PeopleRepository db) =>
            await db.DeleteAsync(id) ? Results.NoContent() : Results.NotFound());

        var repository = app.Services.GetRequiredService<PeopleRepository>();
        await repository.InitializeAsync();
        app.Logger.LogInformation("Backend {Backend}; SO real: {OS}; almacenamiento: {Provider}",
            backend, RuntimeInformation.OSDescription, repository.Provider);
        await app.RunAsync();
    }
}
