# Lector sencillo de .env: KEY=valor, comillas exteriores opcionales, sin evaluar código.
function Import-ProjectEnv([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    $allowedKeys = @("POSTGRES_DB", "POSTGRES_USER", "POSTGRES_PASSWORD", "POSTGRES_PORT")
    foreach ($line in [System.IO.File]::ReadAllLines($Path)) {
        if ($line -match '^\s*(POSTGRES_[A-Z_]+)\s*=(.*)$') {
            $envKey = $matches[1]
            $envValue = $matches[2].Trim()
            if ($allowedKeys -notcontains $envKey) { continue }
            if ($envValue.Length -ge 2 -and (($envValue.StartsWith("'") -and $envValue.EndsWith("'")) -or ($envValue.StartsWith('"') -and $envValue.EndsWith('"')))) {
                $envValue = $envValue.Substring(1, $envValue.Length - 2)
            }
            if (-not [Environment]::GetEnvironmentVariable($envKey, "Process")) {
                [Environment]::SetEnvironmentVariable($envKey, $envValue, "Process")
            }
        }
    }
}
