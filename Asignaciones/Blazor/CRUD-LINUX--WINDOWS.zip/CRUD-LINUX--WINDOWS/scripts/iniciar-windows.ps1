param(
    [string]$BindAddress = "127.0.0.1",
    [ValidateRange(1,65535)][int]$Port = 5001,
    [string]$PostgresHost
)
$ErrorActionPreference = "Stop"
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw "Instale .NET SDK 10. Consulte docs/TUTORIAL.md."
}
. (Join-Path $PSScriptRoot "cargar-env.ps1")
Import-ProjectEnv (Join-Path $PSScriptRoot "..\.env")
if ($PostgresHost) { $env:Postgres__Host = $PostgresHost }
if (-not $env:Postgres__Port -and $env:POSTGRES_PORT) { $env:Postgres__Port = $env:POSTGRES_PORT }
if (-not $env:Postgres__Database -and $env:POSTGRES_DB) { $env:Postgres__Database = $env:POSTGRES_DB }
if (-not $env:Postgres__Username -and $env:POSTGRES_USER) { $env:Postgres__Username = $env:POSTGRES_USER }
if (-not $env:Postgres__Password -and $env:POSTGRES_PASSWORD) { $env:Postgres__Password = $env:POSTGRES_PASSWORD }
if (-not $env:Postgres__Password -and -not $env:ConnectionStrings__People) {
    throw "Falta la clave PostgreSQL. Copie .env.example a .env y configure POSTGRES_PASSWORD."
}
Push-Location (Join-Path $PSScriptRoot "..\BackendWindows")
try {
    & dotnet run --project BackendWindows.csproj -c Release --no-launch-profile -- --urls "http://${BindAddress}:$Port"
    if ($LASTEXITCODE -ne 0) { throw "El backend finalizo con codigo $LASTEXITCODE. Revise PostgreSQL y su configuracion." }
} finally { Pop-Location }
