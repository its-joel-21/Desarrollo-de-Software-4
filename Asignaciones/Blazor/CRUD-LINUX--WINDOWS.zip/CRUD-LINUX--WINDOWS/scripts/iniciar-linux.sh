#!/usr/bin/env bash
set -euo pipefail
# Alternativa sin contenedor: bash scripts/iniciar-linux.sh [interfaz API] [puerto API]
bind_address="${1:-127.0.0.1}"
api_port="${2:-5002}"
if [[ ! "$api_port" =~ ^[0-9]+$ ]] || ((10#$api_port < 1 || 10#$api_port > 65535)); then
  echo "El puerto debe estar entre 1 y 65535." >&2; exit 1
fi
command -v dotnet >/dev/null 2>&1 || { echo "Instale .NET SDK 10." >&2; exit 1; }
script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
env_file="$script_dir/../.env"
# No se usa source/eval para leer el archivo de configuración.
if [[ -f "$env_file" ]]; then
  while IFS= read -r line || [[ -n "$line" ]]; do
    line="${line%$'\r'}"
    if [[ "$line" =~ ^(POSTGRES_DB|POSTGRES_USER|POSTGRES_PASSWORD|POSTGRES_PORT)=(.*)$ ]]; then
      env_key="${BASH_REMATCH[1]}"; env_value="${BASH_REMATCH[2]}"
      if (( ${#env_value} >= 2 )) && [[ "$env_value" == \"*\" || "$env_value" == \'*\' ]]; then env_value="${env_value:1:${#env_value}-2}"; fi
      if [[ -z "${!env_key:-}" ]]; then export "$env_key=$env_value"; fi
    fi
  done < "$env_file"
fi
export Postgres__Port="${Postgres__Port:-${POSTGRES_PORT:-5432}}"
export Postgres__Database="${Postgres__Database:-${POSTGRES_DB:-crud_personas}}"
export Postgres__Username="${Postgres__Username:-${POSTGRES_USER:-crud_app}}"
export Postgres__Password="${Postgres__Password:-${POSTGRES_PASSWORD:-}}"
if [[ -z "$Postgres__Password" && -z "${ConnectionStrings__People:-}" ]]; then
  echo "Falta la clave PostgreSQL. Copie .env.example a .env y configure POSTGRES_PASSWORD." >&2; exit 1
fi
cd "$script_dir/../BackendLinux"
exec dotnet run --project BackendLinux.csproj -c Release --no-launch-profile -- --urls "http://${bind_address}:${api_port}"
