<# Referencia SSH archivada; el script no forma parte del flujo activo.
param(
    [Parameter(Mandatory=$true)][ValidateSet("Windows", "Linux")][string]$Target,
    [Parameter(Mandatory=$true)][ValidatePattern('^[a-zA-Z0-9_.-]+$')][string]$RemoteUser,
    [Parameter(Mandatory=$true)][ValidatePattern('^[a-zA-Z0-9][a-zA-Z0-9_.:-]*$')][string]$RemoteHost,
    [ValidateRange(1,65535)][int]$SshPort = 22,
    [ValidateRange(0,65535)][int]$LocalPort = 0,
    [ValidateRange(0,65535)][int]$RemoteApiPort = 0
)
$ErrorActionPreference = "Stop"
if (-not (Get-Command ssh -ErrorAction SilentlyContinue)) {
    throw "Instale OpenSSH Client en las características opcionales de Windows."
}
if ($RemoteApiPort -eq 0) { $RemoteApiPort = if ($Target -eq "Windows") { 5001 } else { 5002 } }
if ($LocalPort -eq 0) { $LocalPort = if ($Target -eq "Windows") { 15001 } else { 15002 } }
Write-Host "Servidor $Target. En el cliente seleccione SSH y http://127.0.0.1:$LocalPort/"
Write-Host "Mantenga esta consola abierta. Ctrl+C cierra el túnel."
& ssh -N -T -o ExitOnForwardFailure=yes -o ServerAliveInterval=30 -o ServerAliveCountMax=3 `
    -p $SshPort -L "127.0.0.1:${LocalPort}:127.0.0.1:${RemoteApiPort}" "${RemoteUser}@${RemoteHost}"
if ($LASTEXITCODE -ne 0) { throw "SSH finalizó con código $LASTEXITCODE." }

#>