using BackendComun;

await ApiHost.RunAsync(args, "Windows", 5001);
