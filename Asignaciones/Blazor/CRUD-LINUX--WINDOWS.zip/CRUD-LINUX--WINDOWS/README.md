# CRUD Linux / Windows

Aplicación Blazor para administrar personas usando una API local en Windows o la API Linux del VPS, publicada de forma segura con Cloudflare Tunnel y Access.

## Inicio rápido para compañeros

### 1. Descarga el proyecto

Instala Git y clona el repositorio. Abre PowerShell y ejecuta:

```powershell
git clone https://github.com/MxguelS/CRUD-LINUX--WINDOWS.git
cd CRUD-LINUX--WINDOWS
```

También puedes descargar el ZIP desde GitHub y extraerlo. En ese caso, abre PowerShell dentro de la carpeta extraída. Necesitas .NET 10 SDK, Visual Studio con la carga **Desarrollo de ASP.NET y web**, y PostgreSQL instalado y ejecutándose en Windows. Docker es opcional.

### 2. Prepara el backend Windows

En PostgreSQL, crea una base y un usuario para la práctica (o usa los que ya tengas). Por ejemplo, desde pgAdmin conectado como administrador, ejecuta:

```sql
CREATE ROLE crud_app WITH LOGIN PASSWORD 'elige_una_clave_local';
CREATE DATABASE crud_personas OWNER crud_app;
```

En PowerShell, desde la carpeta raíz del repositorio, crea el archivo de configuración local y ábrelo:

```powershell
Copy-Item .env.example .env
notepad .env
```

En `.env`, configura `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD` y `POSTGRES_PORT` para que coincidan con la base, usuario, clave y puerto de PostgreSQL. Guarda el archivo. No lo subas a GitHub.

Inicia el backend Windows:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\iniciar-windows.ps1
```

Deja esa ventana abierta. La API local queda disponible en `http://127.0.0.1:5001/`.

### 3. Configura el acceso al Linux del VPS

Pídele al dueño del proyecto **por un canal privado** estos datos: hostname/subdominio HTTPS, `Client ID` y `Client Secret` del Service Token de Cloudflare Access. El dueño también debe autorizar ese token en la política de Access. No pegues los secretos en GitHub, en el código ni en un chat público.

En Visual Studio, haz clic derecho en **ClienteBlazor** → **Administrar secretos de usuario**. En el archivo que se abre, coloca los datos recibidos:

```json
{
  "CloudflareAccess": {
    "Hostname": "api.tu-subdominio.dev",
    "ApiBaseUrl": "https://api.tu-subdominio.dev/",
    "ClientId": "PEGA_AQUI_EL_CLIENT_ID",
    "ClientSecret": "PEGA_AQUI_EL_CLIENT_SECRET"
  }
}
```

Reemplaza el ejemplo del subdominio por el que te dio el dueño. `Hostname` lleva solo el dominio, sin `https://` ni `/`; `ApiBaseUrl` lleva la URL completa y termina en `/`. Guarda y cierra el archivo.

### 4. Ejecuta Blazor y elige el backend

En Visual Studio, abre `Asignacion4.sln`. En el Explorador de soluciones, haz clic derecho en **ClienteBlazor** → **Establecer como proyecto de inicio**. Pulsa **F5**.

- Elige **Windows** para usar la API que iniciaste en el paso 2. URL: `http://127.0.0.1:5001/`.
- Elige **Linux** para usar el backend del VPS a través del subdominio de Cloudflare y el Service Token.

Así puedes probar ambos backends desde la misma interfaz Blazor. Las bases de Windows y Linux son independientes; los registros no se sincronizan automáticamente.

## Cómo está organizado

| Carpeta | Contenido |
|---|---|
| `ClienteBlazor/` | Interfaz web Blazor Server |
| `BackendWindows/` | API ASP.NET Core para Windows |
| `BackendLinux/` | API Linux y configuración Docker del VPS |
| `BackendComun/` | Endpoints, validación y acceso a datos compartidos |
| `scripts/` | Scripts de inicio y carga de configuración |
| `docs/` | Configuración de Cloudflare, API y referencias adicionales |

La API Linux del VPS se publica mediante Cloudflare Tunnel; no es necesario instalar `cloudflared` en los equipos de los compañeros. La configuración del VPS está en [`docs/DOCKER.md`](docs/DOCKER.md) y los detalles de Cloudflare Access en [`docs/CLOUDFLARE.md`](docs/CLOUDFLARE.md). La guía larga [`docs/TUTORIAL.md`](docs/TUTORIAL.md) conserva escenarios históricos de WSL/VM que no se necesitan para el flujo anterior.

## Seguridad y datos

- No subas `.env`, secretos de Cloudflare, contraseñas ni datos locales al repositorio.
- No expongas PostgreSQL del VPS a Internet; el cliente usa la API y Cloudflare Tunnel.
- Docker solo hace falta en Windows si quieres correr PostgreSQL en un contenedor; el backend Windows puede usar PostgreSQL instalado directamente.
