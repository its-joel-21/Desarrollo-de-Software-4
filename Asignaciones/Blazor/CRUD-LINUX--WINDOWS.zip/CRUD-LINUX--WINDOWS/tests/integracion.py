#!/usr/bin/env python3
"""Pruebas REST reales; solo usa la biblioteca estándar de Python 3.10+."""
import argparse
import concurrent.futures
import json
import re
import os
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


def free_port():
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def request(base, method="GET", path="api/people", data=None, expected=200):
    body = None if data is None else json.dumps(data).encode()
    req = urllib.request.Request(base + path, data=body, method=method,
                                 headers={"Content-Type": "application/json"})
    try:
        response = urllib.request.urlopen(req, timeout=20)
    except urllib.error.HTTPError as error:
        response = error
    with response:
        raw = response.read()
        assert response.code == expected, (method, path, response.code, raw)
        result = json.loads(raw) if raw else None
        return result, response.headers


class Backend:
    def __init__(self, dotnet, name, folder, connection_string):
        self.dotnet, self.name = dotnet, name
        self.folder = folder
        self.port = free_port()
        self.base = f"http://127.0.0.1:{self.port}/"
        self.connection_string = connection_string
        self.process = None
        self.log = None

    def start(self):
        self.log = (self.folder / f"{self.name}.log").open("a")
        project = ROOT / f"Backend{self.name}"
        dll = project / f"bin/Release/net10.0/Backend{self.name}.dll"
        env = os.environ.copy()
        env["ConnectionStrings__People"] = self.connection_string
        self.process = subprocess.Popen([self.dotnet, str(dll), "--urls", self.base],
            cwd=project, env=env, stdout=self.log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            if self.process.poll() is not None:
                raise AssertionError((self.folder / f"{self.name}.log").read_text())
            try:
                health, _ = request(self.base, path="api/health")
                assert health["backend"] == self.name and health["status"] == "ok"
                return health
            except (OSError, urllib.error.URLError):
                time.sleep(0.1)
        raise TimeoutError("La API no inició: " + self.name)

    def stop(self):
        if self.process and self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=5)
        if self.log:
            self.log.close()


def crud(backend):
    base = backend.base
    people, _ = request(base)
    assert len(people) == 43
    for invalid in [{}, {"name": " ", "age": 20}, {"name": "X" * 101, "age": 20},
                    {"name": "X", "age": -1}, {"name": "X", "age": 121},
                    {"name": "X"}, {"name": None, "age": 20}, {"name": "X", "age": 1.5}]:
        request(base, "POST", data=invalid, expected=400)
    assert len(request(base)[0]) == 43
    name = f"Prueba {backend.name} José O'Connor % _ & +"
    person, headers = request(base, "POST", data={"name": "  " + name + "  ", "age": 0}, expected=201)
    assert person["name"] == name and person["age"] == 0
    assert headers["Location"] == f"/api/people/{person['id']}"
    path = f"api/people/{person['id']}"
    assert request(base, path=path)[0] == person
    search = "api/people?name=" + urllib.parse.quote("O'Connor % _ & +", safe="")
    assert request(base, path=search)[0] == [person]
    request(base, "PUT", path, {"name": "", "age": 25}, expected=400)
    assert request(base, path=path)[0] == person
    request(base, "PUT", path, {"name": name + " editado", "age": 120}, expected=204)
    assert request(base, path=path)[0]["age"] == 120
    request(base, "DELETE", path, expected=204)
    for method in ["GET", "PUT", "DELETE"]:
        request(base, method, path,
                {"name": "Ausente", "age": 20} if method == "PUT" else None, expected=404)
    request(base, path="api/people/no-es-numero", expected=404)


def run(dotnet):
    connection = os.environ.get("TEST_POSTGRES_CONNECTION", "")
    if not re.search(r"(?:^|;)\s*Database\s*=\s*asignacion4_test_[a-z0-9_]+(?:;|$)", connection, re.I):
        raise SystemExit("Use TEST_POSTGRES_CONNECTION con una base temporal llamada asignacion4_test_..., ya creada. Las pruebas borran sus registros.")
    with tempfile.TemporaryDirectory(prefix="asignacion4-test-") as directory:
        folder = Path(directory)
        windows, linux = [Backend(dotnet, name, folder, connection) for name in ["Windows", "Linux"]]
        try:
            health = [windows.start(), linux.start()]
            assert all(h["storage"] == "PostgreSQL" for h in health)
            crud(windows)
            crud(linux)
            saved, _ = request(windows.base, "POST", data={"name": "Compartido Windows Linux", "age": 27}, expected=201)
            path = f"api/people/{saved['id']}"
            assert request(linux.base, path=path)[0] == saved
            request(linux.base, "PUT", path, {"name": "Editado desde Linux", "age": 28}, expected=204)
            assert request(windows.base, path=path)[0]["age"] == 28
            request(windows.base, "DELETE", path, expected=204)
            with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
                creations = list(pool.map(lambda i: request(linux.base, "POST",
                    data={"name": f"Concurrencia {i}", "age": i}, expected=201)[0], range(12)))
            assert len({p["id"] for p in creations}) == 12
            assert len(request(windows.base)[0]) == 55
            for person in creations:
                request(linux.base, "DELETE", f"api/people/{person['id']}", expected=204)
            saved, _ = request(linux.base, "POST", data={"name": "Persistente", "age": 27}, expected=201)
            linux.stop()
            linux.start()
            assert len(request(linux.base)[0]) == 44
            assert request(linux.base, path=f"api/people/{saved['id']}")[0] == saved
            windows.stop()
            try:
                request(windows.base)
                raise AssertionError("El backend Windows debía estar detenido")
            except (OSError, urllib.error.URLError):
                pass
            assert len(request(linux.base)[0]) == 44
            request(linux.base, "DELETE", f"api/people/{saved['id']}", expected=204)
            for person in request(linux.base)[0]:
                request(linux.base, "DELETE", f"api/people/{person['id']}", expected=204)
            linux.stop()
            linux.start()
            assert request(linux.base)[0] == []
            print(json.dumps({"resultado": "OK", "escenarios": ["CRUD en ambos procesos", "validaciones REST",
                "búsqueda literal y Unicode", "404", "base PostgreSQL compartida", "escrituras concurrentes",
                "persistencia sin duplicar semilla", "caída independiente de APIs"], "servidores": health}, ensure_ascii=False, indent=2))
        finally:
            windows.stop()
            linux.stop()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--dotnet", default=shutil.which("dotnet") or "dotnet")
    args = parser.parse_args()
    run(args.dotnet)
