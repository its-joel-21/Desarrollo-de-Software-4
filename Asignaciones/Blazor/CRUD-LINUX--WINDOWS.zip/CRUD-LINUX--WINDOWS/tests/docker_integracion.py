#!/usr/bin/env python3
"""Prueba el contenedor y su volumen en un proyecto Compose temporal separado."""
import json
import os
from pathlib import Path
import shutil
import subprocess
from types import SimpleNamespace
import uuid

from integracion import crud, free_port, request

ROOT = Path(__file__).resolve().parents[1]


def main():
    if not shutil.which("docker"):
        raise SystemExit("Se requiere Docker Engine o Docker Desktop con Docker Compose.")
    subprocess.run(["docker", "info"], check=True, stdout=subprocess.DEVNULL)
    env = os.environ.copy()
    env["LINUX_BIND_ADDRESS"] = "127.0.0.1"
    env["LINUX_API_PORT"] = str(free_port())
    env["POSTGRES_PORT"] = str(free_port())
    env["POSTGRES_DB"] = "asignacion4_test_docker"
    env["POSTGRES_USER"] = "crud_test"
    env["POSTGRES_PASSWORD"] = uuid.uuid4().hex
    base = f"http://127.0.0.1:{env['LINUX_API_PORT']}/"
    project = "asignacion4-test-" + uuid.uuid4().hex[:10]
    command = ["docker", "compose", "--project-name", project, "--file", str(ROOT / "compose.yaml")]

    def compose(*args, capture=False):
        return subprocess.run(command + list(args), cwd=ROOT, env=env, check=True,
                              text=True, capture_output=capture, timeout=900)

    try:
        compose("config", "--quiet")
        compose("up", "-d", "--build", "--wait", "--wait-timeout", "120")
        health, _ = request(base, path="api/health")
        assert health["backend"] == "Linux" and health["storage"] == "PostgreSQL"
        os_release = compose("exec", "-T", "backend-linux", "cat", "/etc/os-release", capture=True).stdout
        assert 'VERSION_ID="22.04"' in os_release, os_release
        uid = compose("exec", "-T", "backend-linux", "id", "-u", capture=True).stdout.strip()
        assert uid == "10001", uid
        pg_version = compose("exec", "-T", "postgres", "psql", "-U", env["POSTGRES_USER"], "-d", env["POSTGRES_DB"], "-Atc", "SHOW server_version;", capture=True).stdout.strip()
        assert pg_version.startswith("17."), pg_version
        crud(SimpleNamespace(base=base, name="Linux"))
        person, _ = request(base, "POST", data={"name": "Persistencia Docker", "age": 27}, expected=201)
        path = f"api/people/{person['id']}"
        compose("up", "-d", "--force-recreate", "--wait", "--wait-timeout", "120")
        assert request(base, path=path)[0] == person
        compose("down")
        compose("up", "-d", "--wait", "--wait-timeout", "120")
        assert request(base, path=path)[0] == person
        request(base, "DELETE", path, expected=204)
        assert len(request(base)[0]) == 43
        print(json.dumps({"resultado": "OK", "health": health,
            "pruebas": ["Ubuntu 22.04", "usuario sin root", "healthcheck", "CRUD REST",
                        "volumen persistente tras recrear y tras down/up"]}, ensure_ascii=False, indent=2))
    except Exception:
        subprocess.run(command + ["logs", "--tail", "120"], cwd=ROOT, env=env, timeout=30)
        raise
    finally:
        # Solo elimina recursos del proyecto temporal con nombre aleatorio.
        compose("down", "--volumes", "--remove-orphans")


if __name__ == "__main__":
    main()
