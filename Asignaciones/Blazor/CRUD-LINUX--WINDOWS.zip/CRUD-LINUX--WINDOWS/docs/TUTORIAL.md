# Tutorial: conectar y usar la aplicación con PostgreSQL

> **Guía histórica de desarrollo local.** Estos pasos de WSL/VM se conservaron como referencia de pruebas anteriores. No son necesarios para el flujo actual ni forman parte del tutorial para compañeros. Para el flujo vigente, usa **Tutorial** dentro de Blazor: Linux se conecta únicamente mediante Cloudflare Tunnel + Access y Windows mediante la API local en `127.0.0.1:5001`. La referencia SSH está archivada en comentarios y no está activa.

## 1. Qué se conecta con qué

| Componente | Dónde se ejecuta | Con quién se comunica |
|---|---|---|
| Cliente Blazor Server | Windows con Visual Studio o .NET 10 | API Windows local 5001 o API Linux HTTPS por Cloudflare Tunnel |
| Backend Windows | Windows local | PostgreSQL local en Windows |
| Backend Linux | Contenedor Ubuntu 22.04 en el VPS | PostgreSQL privado en el mismo VPS |
<!-- SSH archivado: | SSH, si se utiliza | Entre el cliente y la máquina Linux | Transporta REST por un túnel cifrado | -->

El cliente nunca se conecta directamente a PostgreSQL. Linux requiere el subdominio HTTPS y el Service Token autorizados; Windows usa la API local. Las bases son independientes en esta configuración.

## 2. Preparación común

### Archivos

Extrae el ZIP. Usaremos como ejemplo `C:\Proyectos\Asignacion4` en Windows y `~/Asignacion4` en Ubuntu. La carpeta correcta contiene `compose.yaml`, `BackendLinux`, `BackendWindows` y `scripts`.

### Requisitos del cliente web

- Visual Studio con la carga de trabajo **Desarrollo de ASP.NET y web**, o .NET SDK 10: https://dotnet.microsoft.com/download/dotnet/10.0

### Configuración de PostgreSQL

Crea `.env` junto a `compose.yaml`. Desde PowerShell:

```powershell
cd C:\Proyectos\Asignacion4
Copy-Item .env.example .env
notepad .env
```

O desde Ubuntu:

```bash
cd ~/Asignacion4
cp .env.example .env
nano .env
```

Hazlo una sola vez por copia del proyecto; no sobrescribas después un `.env` que ya configuraste. Contenido de ejemplo:

```dotenv
POSTGRES_DB=crud_personas
POSTGRES_USER=crud_app
POSTGRES_PASSWORD=PonAquiTuClave2026
POSTGRES_PORT=5432
LINUX_BIND_ADDRESS=127.0.0.1
LINUX_API_PORT=5002
```

Sustituye la contraseña de ejemplo. Para esta práctica usa letras, números, guion y guion bajo: así puedes usar el mismo archivo tanto con Compose como con los lectores de los scripts nativos sin reglas de interpolación adicionales. No incluyas `.env` al compartir el código. Si el backend Windows va a usar esta misma base, su copia de `.env` debe tener el mismo usuario, base y contraseña.

`POSTGRES_PORT` es el puerto de acceso desde el anfitrión. Dentro de Docker, la API siempre usa `postgres:5432`. Cambiar `POSTGRES_PORT` no cambia ese puerto interno.

## A. Linux usando WSL2 en tu PC Windows

### A1. Instalar Ubuntu 22.04

En **PowerShell como administrador**:

```powershell
wsl --install -d Ubuntu-22.04
```

Reinicia si Windows lo solicita y termina la creación de usuario/contraseña de Ubuntu. Después comprueba:

```powershell
wsl -l -v
```

Ubuntu-22.04 debe aparecer con versión **2**. Si aparece versión 1:

```powershell
wsl --set-version Ubuntu-22.04 2
```

### A2. Instalar Docker Desktop

Instala Docker Desktop para Windows: https://docs.docker.com/desktop/setup/install/windows-install/

Abre Docker Desktop. En Settings activa el motor basado en WSL2 y en Resources → WSL Integration habilita Ubuntu-22.04. Aplica los cambios. Usa contenedores Linux. Con esta integración, Docker Desktop administra el motor; no necesitas instalar otro Docker Engine dentro de Ubuntu.

### A3. Preparar el proyecto dentro de Ubuntu

Abre **Ubuntu-22.04**, por ejemplo desde el menú Inicio. Comprueba:

```bash
cat /etc/os-release
docker version
docker compose version
```

Si el proyecto está en `C:\Proyectos\Asignacion4`, cópialo al directorio personal de Ubuntu:

```bash
cp -r /mnt/c/Proyectos/Asignacion4 ~/
cd ~/Asignacion4
```

Si no creaste `.env` antes, copia `.env.example` y edítalo como se indica en la sección 2. Si lo copiaste ya configurado, consérvalo.

### A4. Levantar API y PostgreSQL

En la **terminal Ubuntu**, dentro del proyecto:

```bash
docker compose up -d --build --wait
docker compose ps
```

La primera construcción puede tardar varios minutos. Al terminar, `postgres` y `backend-linux` deben estar funcionando y saludables. Comprueba:

```bash
curl http://127.0.0.1:5002/api/health
```

La respuesta debe contener `status: ok`, `backend: Linux`, `storage: PostgreSQL` y Ubuntu 22.04 en `os`.

Desde **PowerShell de Windows** también puedes comprobarlo:

```powershell
Invoke-RestMethod http://127.0.0.1:5002/api/health
```

### A5. Abrir y conectar el cliente desde Visual Studio

Abre `Asignacion4.sln` en Visual Studio. En el Explorador de soluciones, haz clic derecho en `ClienteBlazor` y elige **Establecer como proyecto de inicio**. Pulsa **Iniciar** o F5. Blazor carga por defecto `http://127.0.0.1:5002/`; usa el panel de conexión en la esquina superior derecha para cambiar entre Windows y Linux o editar la URL.

Selecciona **Linux**, conexión **Direct** y URL **`http://127.0.0.1:5002/`**. Pulsa **Probar y conectar**. Deberías ver los 43 registros iniciales, salvo que ya hayas modificado esa base.

Si falla, revisa primero que Docker Desktop siga abierto y que la distribución esté integrada. Usa `docker compose logs --tail 80 backend-linux postgres` en Ubuntu. Si necesitas comprobar la IP de una distribución WSL, desde Windows ejecuta `wsl -d Ubuntu-22.04 hostname -I`; no sustituyas automáticamente localhost por esa IP cuando Docker Desktop es quien publica los puertos en Windows.

## B. Linux usando una máquina virtual Ubuntu 22.04

### B1. Crear la VM y su red

Instala Ubuntu **22.04 LTS** en VirtualBox, VMware o Hyper-V. Como punto de partida para la práctica, asigna 2 CPU y 4 GB de RAM si tu equipo puede compartirlos.

Para acceso directo desde el anfitrión usa adaptador en **puente** o **solo anfitrión**. Si eliges solo anfitrión, un segundo adaptador NAT puede dar acceso a internet para las descargas. En la VM consulta su IP con:

```bash
hostname -I
```

En los ejemplos usaremos `192.168.1.50`; cámbiala por la IP real de tu VM.

### B2. Instalar Docker Engine y Compose dentro de la VM

En una instalación limpia de Ubuntu 22.04, desde su terminal:

```bash
sudo apt update
sudo apt install -y ca-certificates curl
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc
printf '%s\n' 'Types: deb' 'URIs: https://download.docker.com/linux/ubuntu' 'Suites: jammy' 'Components: stable' "Architectures: $(dpkg --print-architecture)" 'Signed-By: /etc/apt/keyrings/docker.asc' | sudo tee /etc/apt/sources.list.d/docker.sources >/dev/null
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
sudo systemctl enable --now docker
sudo docker version
sudo docker compose version
```

Si ya instalaste Docker por otro método, revisa los paquetes en conflicto en la guía oficial antes de cambiar su instalación: https://docs.docker.com/engine/install/ubuntu/

En estos pasos usaremos `sudo docker`. Si configuraste acceso al daemon para tu usuario, puedes omitir `sudo`.

### B3. Copiar y configurar

Copia el proyecto completo a `~/Asignacion4` en la VM (carpeta compartida, SCP o el método de tu hipervisor). Crea `.env` y cambia estas líneas:

```dotenv
LINUX_BIND_ADDRESS=0.0.0.0
LINUX_API_PORT=5002
```

Mantén las credenciales PostgreSQL de la sección 2. PostgreSQL permanece publicado solo en loopback; el cliente necesita acceso a la API.

### B4. Arrancar

Dentro de la **VM Ubuntu**:

```bash
cd ~/Asignacion4
sudo docker compose up -d --build --wait
sudo docker compose ps
curl http://127.0.0.1:5002/api/health
```

En **Windows del cliente**:

```powershell
Test-NetConnection 192.168.1.50 -Port 5002
Invoke-RestMethod http://192.168.1.50:5002/api/health
```

Abre el cliente y selecciona **Linux → Direct → `http://192.168.1.50:5002/`**.

Si la prueba dentro de la VM funciona pero la de Windows falla, revisa la IP, el adaptador de red y las reglas de publicación/firewall. Docker gestiona reglas propias; no asumas que una regla UFW por sí sola limita un puerto publicado.

### B5. Si la VM usa solamente NAT

Configura un reenvío en tu hipervisor:

| Protocolo | IP anfitrión | Puerto anfitrión | Puerto invitado |
|---|---|---:|---:|
| TCP | 127.0.0.1 | 16002 | 5002 |

Dentro de la VM conserva `LINUX_BIND_ADDRESS=0.0.0.0`. Desde el Windows anfitrión el cliente usa **`http://127.0.0.1:16002/`**. Si el hipervisor solicita IP invitado, introduce la IP de la VM. El puerto anfitrión debe estar libre.

<!-- Se conserva como referencia, pero no se usa en esta entrega.
<!-- SSH archivado: se conserva esta ruta de referencia, pero no está habilitada en el cliente.
## C. Linux en otra máquina mediante SSH

Sirve tanto para una VM como para una computadora Ubuntu aparte. API y PostgreSQL se ejecutan allí; el cliente permanece en tu Windows.

### C1. Preparar el servidor Ubuntu

Instala Docker siguiendo B2 y copia el proyecto. En `.env` usa:

```dotenv
LINUX_BIND_ADDRESS=127.0.0.1
LINUX_API_PORT=5002
```

Arranca en la máquina **remota**:

```bash
cd ~/Asignacion4
sudo docker compose up -d --build --wait
curl http://127.0.0.1:5002/api/health
sudo apt update
sudo apt install -y openssh-server
sudo systemctl enable --now ssh
sudo systemctl status ssh
```

El servicio SSH se ejecuta en Ubuntu anfitrión, fuera de los contenedores. Si usas firewall, permite el puerto SSH desde la IP del cliente. No necesitas publicar el HTTP de la API en todas las interfaces para este caso.

### C2. Comprobar acceso desde Windows

En **PowerShell del cliente**, sustituyendo usuario e IP:

```powershell
ssh antonio@192.168.1.50
```

Comprueba la huella del servidor al conectar por primera vez. Escribe la contraseña de ese **usuario Ubuntu**, o usa tus claves SSH. Esta contraseña es distinta de la de PostgreSQL.

Si accedes correctamente, ejecuta `exit` para volver a PowerShell.

### C3. Abrir el túnel

Desde la carpeta Windows del proyecto:

```powershell
cd C:\Proyectos\Asignacion4
powershell -ExecutionPolicy Bypass -File .\scripts\tunel-ssh.ps1 -Target Linux -RemoteUser antonio -RemoteHost 192.168.1.50
```

Deja esa consola abierta. Es normal que no muestre un shell. El comando equivalente es:

```powershell
ssh -N -T -o ExitOnForwardFailure=yes -o ServerAliveInterval=30 -L 127.0.0.1:15002:127.0.0.1:5002 antonio@192.168.1.50
```

La ruta es: **cliente local 15002 → SSH → puerto 5002 del servidor → API 8080 del contenedor → PostgreSQL interno**.

### C4. Conectar el cliente por el túnel

En otra consola PowerShell:

```powershell
Invoke-RestMethod http://127.0.0.1:15002/api/health
```

Abre la aplicación y selecciona **Linux → SSH → `http://127.0.0.1:15002/`**. Pulsa **Probar y conectar** y utiliza el CRUD normalmente. Ctrl+C en la consola del túnel lo cierra; el servidor remoto sigue funcionando.

### C5. SSH a una VM con NAT

En el hipervisor reenvía TCP `127.0.0.1:2222` del anfitrión al puerto `22` del invitado. Después:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\tunel-ssh.ps1 -Target Linux -RemoteUser antonio -RemoteHost 127.0.0.1 -SshPort 2222
```
-->

El cliente sigue usando `http://127.0.0.1:15002/`. Si el servidor publica su API en otro puerto, añade `-RemoteApiPort PUERTO` al script.

## 3. Levantar también el backend Windows

### Misma PC: PostgreSQL de Docker Desktop/WSL

Con Compose iniciado, PostgreSQL publica `127.0.0.1:5432` para que el backend Windows pueda utilizarlo. Comprueba desde PowerShell:

```powershell
Test-NetConnection 127.0.0.1 -Port 5432
```

En la copia Windows del proyecto, configura `.env` con la **misma** base, usuario y contraseña que la copia de WSL. Con .NET SDK 10 instalado:

```powershell
cd C:\Proyectos\Asignacion4
powershell -ExecutionPolicy Bypass -File .\scripts\iniciar-windows.ps1
```

Deja esta consola abierta. Verifica:

```powershell
Invoke-RestMethod http://127.0.0.1:5001/api/health
```

En la aplicación pulsa **Cambiar servidor → Windows → Direct → `http://127.0.0.1:5001/`**. Un registro creado en Linux debe aparecer en Windows cuando ambos apuntan a la misma base PostgreSQL.

### Base compartida en una VM o equipo remoto

PostgreSQL queda en loopback del servidor. Puedes llevarlo a Windows por un segundo túnel SSH:

```powershell
ssh -N -T -o ExitOnForwardFailure=yes -L 127.0.0.1:15432:127.0.0.1:5432 antonio@192.168.1.50
```

Mantén esa consola abierta. En la copia Windows de `.env`, usa `POSTGRES_PORT=15432` y las mismas credenciales/base que el servidor. Inicia `iniciar-windows.ps1`; se conectará a `127.0.0.1:15432`. Este túnel es para la conexión **backend Windows → PostgreSQL**, distinto del túnel de la API Linux.

También se puede usar PostgreSQL instalado directamente en Windows: crea el usuario y la base y configura sus valores. En pgAdmin, conectado como administrador, ejecuta por separado:

```sql
CREATE ROLE crud_app LOGIN PASSWORD 'PonAquiTuClave2026';
CREATE DATABASE crud_personas OWNER crud_app;
```

Ejecuta `CREATE DATABASE` fuera de una transacción. La API se conecta con `crud_app` y crea la tabla. PostgreSQL debe estar iniciado. Para compartir con Linux, ambos backends necesitan apuntar a una instancia alcanzable; no basta con crear dos bases distintas con el mismo nombre.

## 4. Cómo usar la aplicación

1. Ejecuta `ClienteBlazor` desde Visual Studio y confirma que el indicador de conexión muestra el backend elegido.
2. Pulsa **Probar y conectar**. Si la API o la base fallan, el cliente muestra el problema.
3. **Nuevo:** escribe nombre (1–100 caracteres) y edad entera (0–120); pulsa Guardar.
4. **Buscar:** escribe parte del nombre y pulsa Buscar. Vacía la búsqueda para listar todos.
5. **Editar:** selecciona una fila, cambia nombre/edad y guarda.
6. **Eliminar:** selecciona la fila y confirma la eliminación en el servidor indicado.
7. **Actualizar:** vuelve a consultar la lista.
8. **Cambiar servidor:** prueba Windows y Linux. El estado inferior muestra la URL, el SO real y PostgreSQL.

Si una escritura agota el tiempo de espera, actualiza antes de repetirla: el servidor pudo guardarla aunque se perdiera la respuesta.

## 5. Ver los datos y detener

Desde la carpeta del proyecto en el anfitrión Docker:

```bash
docker compose exec postgres sh -c 'psql -U "$POSTGRES_USER" -d "$POSTGRES_DB"'
```

Dentro de `psql`:

```sql
SELECT id, name, age FROM public.people ORDER BY id;
SELECT COUNT(*) FROM public.people;
```

Sal con `\q`. En Ubuntu con Docker Engine añade `sudo` a `docker` si tu cuenta lo necesita.

Para detener y conservar la base:

```bash
docker compose down
```

Para volver a usarla:

```bash
docker compose up -d --wait
```

**No añadas `--volumes` si quieres conservar los registros.** No se migra automáticamente la base de versiones anteriores.

La contraseña inicial se aplica al crear el volumen PostgreSQL. Si cambias únicamente `POSTGRES_PASSWORD` en `.env` con un volumen ya inicializado, el usuario de la base conserva la contraseña anterior. Para cambiarla, entra a `psql` y ejecuta `\password crud_app`; después actualiza `.env` en los backends y recrea la API con `docker compose up -d --force-recreate backend-linux`. Mantén el volumen.

## 6. Problemas frecuentes

| Síntoma | Qué revisar |
|---|---|
| `docker: command not found` en WSL | Docker Desktop iniciado y Ubuntu-22.04 habilitado en WSL Integration |
| `Cannot connect to the Docker daemon` | Docker Desktop o servicio Docker funcionando; permisos del usuario |
| Puerto 5002 ocupado | Detén la versión nativa anterior o cambia `LINUX_API_PORT=16002`; cambia también la URL del cliente |
| Puerto 5432 ocupado | Usa `POSTGRES_PORT=15433` en `.env`; el backend Windows debe usar ese mismo puerto publicado |
| `password authentication failed` | Usuario/contraseña coincidentes; cambiar `.env` no cambia una contraseña del volumen ya creado |
| `database ... does not exist` | Base creada, nombre correcto y PostgreSQL alcanzable |
| Health devuelve 500 | Revisa `docker compose logs --tail 80 backend-linux postgres` |
| Windows no llega a la VM | IP, puente/solo anfitrión/NAT y `LINUX_BIND_ADDRESS=0.0.0.0` para acceso directo |
| La app dice que no corresponde al backend | Elegiste Windows con URL Linux o viceversa; revisa `/api/health` |
| Un registro no aparece al cambiar servidor | Comprueba que ambos backends usan exactamente la misma instancia y base PostgreSQL |

La API se entrega para la práctica sin autenticación de usuarios. Usa localhost o una red privada/de laboratorio para acceder al backend. PostgreSQL permanece limitado a localhost en Compose.

## Referencias oficiales

- WSL: https://learn.microsoft.com/windows/wsl/install
- Integración de Docker Desktop con WSL: https://docs.docker.com/desktop/features/wsl/
- Red de WSL: https://learn.microsoft.com/windows/wsl/networking
- Docker Engine en Ubuntu: https://docs.docker.com/engine/install/ubuntu/
- Imagen PostgreSQL: https://hub.docker.com/_/postgres
- Npgsql: https://www.npgsql.org/doc/basic-usage.html
<!-- Referencia SSH conservada por si se reactiva esta opción:
- Túneles SSH: https://man.openbsd.org/ssh
-->
