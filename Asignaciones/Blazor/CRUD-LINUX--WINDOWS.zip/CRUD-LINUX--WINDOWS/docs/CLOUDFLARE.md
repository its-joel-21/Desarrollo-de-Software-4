# Cliente Blazor y Cloudflare Access

El backend Linux del VPS se publica por el túnel en el subdominio HTTPS que entrega el responsable (por defecto `https://api.aonis.dev/`) y la política de Cloudflare Access requiere un Service Token. Blazor Server realiza las solicitudes desde el proceso local de Visual Studio y agrega los encabezados de Access solo cuando el destino coincide exactamente con el hostname configurado. La URL Linux queda bloqueada en la interfaz para evitar una ruta directa. El secreto no se envía al navegador ni se incluye en Git.

## Configurar los secretos en Windows

En Visual Studio, haz clic derecho en **ClienteBlazor** y elige **Administrar secretos de usuario**. En el archivo local que se abre, agrega el hostname asignado, la URL HTTPS y el Client ID y Client Secret del Service Token:

```json
{
  "CloudflareAccess": {
    "Hostname": "api.aonis.dev",
    "ApiBaseUrl": "https://api.aonis.dev/",
    "ClientId": "PEGA_AQUI_EL_CLIENT_ID",
    "ClientSecret": "PEGA_AQUI_EL_CLIENT_SECRET"
  }
}
```

Guarda el archivo y vuelve a iniciar ClienteBlazor. User Secrets mantiene este archivo fuera del repositorio y de la carpeta publicada; es almacenamiento local de desarrollo, no un almacén cifrado para producción. No pegues el secreto en el código, en `appsettings.json`, en GitHub ni en el navegador.

## Conectar y comprobar

El cliente selecciona Linux y prellena la URL de `ApiBaseUrl`. Pulsa **Probar conexión**. La API debe responder con backend `Linux` y almacenamiento `PostgreSQL`. Para permitir acceso a compañeros, el responsable debe emitir y autorizar sus tokens de servicio; comparte los valores de cada token de forma privada, nunca en el repositorio.

Una petición anónima a `https://api.aonis.dev/api/health` debe recibir `403`; es el bloqueo esperado de Access. Desde Blazor, con los dos valores configurados, las solicitudes deben pasar. No pruebes el secreto con `curl` en una línea de comandos ni lo compartas en capturas o chats.

## Uso desde otro equipo

Si otro equipo ejecuta la interfaz Blazor, necesita configurar su propio User Secrets para el Service Token y el subdominio que le dio el responsable. No publiques el Client Secret en una app Blazor WebAssembly ni lo insertes en código JavaScript: cualquier valor enviado al navegador puede ser inspeccionado por sus usuarios. El tutorial integrado en `/tutorial` explica también cómo levantar la API Windows con PostgreSQL local, sin requerir Docker.
