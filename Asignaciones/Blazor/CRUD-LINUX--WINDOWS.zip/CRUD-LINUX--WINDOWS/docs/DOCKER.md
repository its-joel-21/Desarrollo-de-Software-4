# Docker: API Linux + PostgreSQL

El procedimiento de instalación, WSL y VM está en **TUTORIAL.md**. Esta es la referencia de operación.

## Primer inicio

Dentro de `Asignacion4`, copia `.env.example` a `.env` y cambia la contraseña. Luego:

```bash
docker compose up -d --build --wait
docker compose ps
```

Compose espera que PostgreSQL esté disponible antes de iniciar la API. La API comprueba además que puede acceder a `public.people` con sus credenciales.

| Servicio | Imagen/base | Puerto interno | Puerto del anfitrión | Persistencia |
|---|---|---:|---|---|
| `backend-linux` | Ubuntu 22.04, .NET 10 autocontenido | 8080 | 127.0.0.1:5002 por defecto | Sin archivos de base locales |
| `postgres` | PostgreSQL 17 (`postgres:17-bookworm`) | 5432 | 127.0.0.1:5432 por defecto | Volumen `postgres-data` en `/var/lib/postgresql/data` |

La API tiene Ubuntu 22.04 como distribución final; el contenedor PostgreSQL usa su propia imagen oficial. Docker comparte el kernel Linux del anfitrión. Windows ejecuta estos contenedores mediante WSL2 o una VM.

## Conexiones

- Dentro de la red Compose: la API usa **`postgres:5432`**.
- Backend Windows en el anfitrión: usa **`127.0.0.1:POSTGRES_PORT`** y las credenciales de `.env`.
- Cliente Blazor: usa la **API** 5001/5002; no utiliza el puerto PostgreSQL.

El Dockerfile incluye SDK solo durante la construcción. La aplicación publicada incluye su runtime y se ejecuta como usuario `app` (UID 10001). Las contraseñas se suministran al ejecutar Compose; `.env` no entra al contexto de construcción.

## Estado y diagnóstico

```bash
docker compose ps
docker compose logs -f backend-linux postgres
curl http://127.0.0.1:5002/api/health
docker compose exec backend-linux cat /etc/os-release
```

Ctrl+C en `logs -f` no detiene los servicios.

## Parar, actualizar y conservar datos

```bash
docker compose down
docker compose up -d --wait
```

El volumen PostgreSQL permanece. **`down --volumes` elimina la base**. Mantén el mismo nombre de proyecto Compose para reutilizar el volumen.

Para reconstruir la API:

```bash
docker compose build --pull backend-linux
docker compose up -d --wait
```

Para actualizar la imagen de base de datos dentro de la misma versión principal, primero respalda la base y luego usa `docker compose pull postgres` y `docker compose up -d --wait`. No cambies la versión principal de PostgreSQL sobre el mismo volumen sin planificar su migración.

## Respaldo desde Ubuntu

```bash
docker compose exec -T postgres sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > respaldo.dump
```

En Windows puedes evitar diferencias de redirección binaria de PowerShell creando el archivo dentro del contenedor y copiándolo:

```powershell
docker compose exec postgres sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc -f /tmp/respaldo.dump'
docker compose cp postgres:/tmp/respaldo.dump ./respaldo.dump
```

Guarda el respaldo fuera del volumen. La restauración debe hacerse en una base de destino apropiada; no reemplaces tus datos de práctica sin conservar su respaldo.

## Distribuir la imagen de la API

Después de construir:

```bash
docker save -o backend-linux.tar asignacion4/backend-linux:local
```

En otro equipo de la misma arquitectura:

```bash
docker load -i backend-linux.tar
docker compose pull postgres
docker compose up -d --no-build --pull never --wait
```

Necesitas copiar también `compose.yaml` y configurar allí `.env`. El TAR de la API no incluye los registros PostgreSQL; estos se transportan con un respaldo aparte. No se incluye una imagen TAR ya construida en el ZIP.

## Prueba del contenedor

```bash
python3 tests/docker_integracion.py
```

Con Docker Engine funcionando, construye e inicia un proyecto de prueba separado con PostgreSQL, prueba CRUD, Ubuntu 22.04, UID 10001 y persistencia después de recrear contenedores y de un ciclo down/up. Sus volúmenes de prueba se eliminan al terminar. El resultado real de las comprobaciones de esta entrega figura en `VERIFICACION.md`.
