# Contrato REST de ambos backends

Las dos APIs utilizan únicamente PostgreSQL y ofrecen el mismo recurso `People`. El cliente usa JSON con propiedades `id`, `name` y `age`. Windows escucha por defecto HTTP 5001; Linux HTTP 5002. El cliente se conecta directamente a la URL del backend seleccionado.

| Método | Ruta | Resultado |
|---|---|---|
| GET | `/api/health` | 200: estado, backend, SO real y almacenamiento; comprueba acceso a la tabla |
| GET | `/api/people` | 200: lista ordenada por ID |
| GET | `/api/people?name=texto` | 200: búsqueda por nombre, subcadena literal |
| GET | `/api/people/{id}` | 200: persona; 404 si falta |
| POST | `/api/people` | 201: persona creada y encabezado `Location` |
| PUT | `/api/people/{id}` | 204: persona actualizada; 404 si falta |
| DELETE | `/api/people/{id}` | 204: persona eliminada; 404 si falta |

POST y PUT requieren `Content-Type: application/json`. Cuerpo:

```json
{
  "name": "Antonio",
  "age": 27
}
```

- El nombre debe tener entre 1 y 100 caracteres después de quitar espacios en los extremos.
- La edad es obligatoria, entera y está entre 0 y 120.
- Datos inválidos devuelven HTTP 400. JSON malformado o tipos incompatibles también fallan.
- `id` lo genera el servidor en POST. PUT utiliza el ID de la ruta.
- Las consultas usan parámetros SQL. `%` y `_` se buscan como caracteres literales.
- La búsqueda usa `strpos(lower(name), lower($1))` en PostgreSQL, con parámetros y subcadenas literales. La conversión de mayúsculas depende de la configuración regional de la base.
- No hay reintentos automáticos de escrituras: ante un timeout se recomienda actualizar la lista antes de repetir, porque el servidor pudo guardar antes de que se perdiera la respuesta.

## Ejemplos desde Ubuntu

```bash
curl http://127.0.0.1:5002/api/health
curl http://127.0.0.1:5002/api/people
curl --get --data-urlencode 'name=Hamilton' http://127.0.0.1:5002/api/people
curl -i -X POST http://127.0.0.1:5002/api/people \
  -H 'Content-Type: application/json' -d '{"name":"Antonio","age":27}'
```

Usa el ID devuelto por POST en las siguientes peticiones, sustituyendo `44` si corresponde:

```bash
curl -i -X PUT http://127.0.0.1:5002/api/people/44 \
  -H 'Content-Type: application/json' -d '{"name":"Antonio editado","age":28}'
curl -i -X DELETE http://127.0.0.1:5002/api/people/44
```

## Ejemplos desde Windows PowerShell

```powershell
$apiUrl = "http://127.0.0.1:5001"
Invoke-RestMethod "$apiUrl/api/health"
$createdPerson = Invoke-RestMethod "$apiUrl/api/people" -Method Post -ContentType "application/json" -Body '{"name":"Antonio","age":27}'
Invoke-RestMethod "$apiUrl/api/people/$($createdPerson.id)" -Method Put -ContentType "application/json" -Body '{"name":"Antonio editado","age":28}'
Invoke-RestMethod "$apiUrl/api/people/$($createdPerson.id)" -Method Delete
```

<!-- Para usar el túnel SSH de Linux cambia `$apiUrl` por `http://127.0.0.1:15002`. -->
