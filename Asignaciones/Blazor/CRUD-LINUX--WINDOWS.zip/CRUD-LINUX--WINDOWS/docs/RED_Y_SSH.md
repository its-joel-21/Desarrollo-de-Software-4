<!-- SSH se conserva como referencia archivada y queda fuera del flujo activo.
# Direcciones y puertos

Los pasos completos están en **TUTORIAL.md**. Todos los ejemplos del cliente son HTTP; el número de puerto 5001 no implica HTTPS en este proyecto.

| Caso | Configuración de la API Linux en `.env` | URL en el cliente |
|---|---|---|
| Docker Desktop/WSL, cliente en la misma PC | `LINUX_BIND_ADDRESS=127.0.0.1`, puerto 5002 | Linux → Direct → `http://127.0.0.1:5002/` |
| VM en puente o solo anfitrión | `LINUX_BIND_ADDRESS=0.0.0.0`, puerto 5002 | Linux → Direct → `http://IP_VM:5002/` |
| VM NAT, reenvío anfitrión 16002 → invitado 5002 | `LINUX_BIND_ADDRESS=0.0.0.0`, puerto 5002 | Linux → Direct → `http://127.0.0.1:16002/` |
| Máquina remota por SSH, túnel local 15002 → remoto 5002 | `LINUX_BIND_ADDRESS=127.0.0.1`, puerto 5002 | Linux → SSH → `http://127.0.0.1:15002/` |
| Backend Windows local | Script nativo escucha en 127.0.0.1:5001 | Windows → Direct → `http://127.0.0.1:5001/` |

`0.0.0.0` es una dirección de escucha; no se escribe como dirección del servidor en el cliente. `127.0.0.1` siempre se refiere al equipo donde se interpreta: con un túnel se usa el puerto **local** del cliente.

## SSH para REST Linux

En el Ubuntu remoto: OpenSSH Server y Compose iniciados. En PowerShell Windows:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\tunel-ssh.ps1 -Target Linux -RemoteUser antonio -RemoteHost 192.168.1.50
```

La API remota sigue usando HTTP; SSH cifra el transporte entre las máquinas. No hace falta instalar SSH dentro del contenedor de la API.

Para una VM con NAT que reenvía anfitrión 2222 → invitado 22:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\tunel-ssh.ps1 -Target Linux -RemoteUser antonio -RemoteHost 127.0.0.1 -SshPort 2222
```

Si cambiaste el puerto de la API remota, utiliza `-RemoteApiPort PUERTO`. Si el 15002 local está ocupado, utiliza `-LocalPort 16002` y cambia la URL del cliente a ese puerto.

## PostgreSQL

Dentro de Compose, la API usa `postgres:5432`. PostgreSQL solo se publica en `127.0.0.1:POSTGRES_PORT` del anfitrión. El cliente gráfico no necesita acceso a ese puerto.

Para que un backend Windows comparta una base situada en otro equipo, el tutorial explica un segundo túnel SSH 15432 → 5432. Esto no es necesario para usar únicamente el cliente con la API Linux.

En redes externas se recomienda el acceso por SSH. Docker administra sus propias reglas de publicación: revisa ese comportamiento antes de exponer una API a todas las interfaces.

-->