# Verificación de esta versión PostgreSQL

Fecha: 28 de octubre de 2026.

## Resultado de compilación

Antes de la migración Blazor, se compiló la solución completa en Release con .NET SDK 10.0.403 y `-m:1`: `BackendComun`, `BackendWindows`, `BackendLinux` y el cliente Windows Forms. Ese resultado corresponde a la revisión anterior y no valida la interfaz Blazor actual.

El único proveedor de base de datos del código es **Npgsql 10.0.3 para PostgreSQL**. Se retiraron los proveedores anteriores, sus opciones de configuración y sus scripts SQL. El cliente mantiene su contrato REST y su compilación para .NET Framework 4.8.

También se publicó correctamente el backend Linux autocontenido para `linux-x64`, que es la modalidad empleada por el Dockerfile.

## Pruebas ejecutadas

En este entorno no hay Docker Engine ni un servidor PostgreSQL nativo instalado. Para comprobar el SQL y las llamadas Npgsql se utilizó **PostgreSQL 18.6 compilado a WebAssembly mediante PGlite 0.5.12**, expuesto por TCP con `pglite-socket`, exclusivamente como herramienta temporal de pruebas. PGlite no es una dependencia ni una alternativa de almacenamiento de la aplicación entregada.

Se ejecutaron ambos procesos ASP.NET Core, con Npgsql, contra esa instancia de pruebas. Pasaron:

1. Health e identificación de Windows/Linux, ambos indicando `PostgreSQL`.
2. Inicialización de 43 registros, sin duplicarlos al arrancar la segunda API.
3. Listado, búsqueda, consulta por ID, creación, edición y eliminación desde ambos procesos.
4. Validación de nombre vacío, nombre nulo/demasiado largo, edad faltante, decimal o fuera de rango.
5. Códigos HTTP 200, 201 con Location, 204, 400 y 404.
6. Nombres con Unicode, apóstrofos, `%`, `_`, `&` y `+`; búsqueda literal.
7. Registro creado en Windows visible en Linux; edición en Linux visible en Windows.
8. Doce creaciones concurrentes con IDs distintos.
9. Persistencia al reiniciar la API y ausencia de reinserción de la semilla después de vaciar la tabla.
10. Detener una API no detiene la otra.

La herramienta de pruebas usa conexiones sin pooling para adaptarse al multiplexor de PGlite. La configuración entregada utiliza el pool de Npgsql, hasta 20 conexiones por backend. La prueba de PGlite no sustituye las garantías de concurrencia y sesiones de un servidor PostgreSQL nativo.

Además se ejecutó `Database/PostgreSQL.sql` sobre una instancia PostgreSQL/PGlite independiente: creó 43 registros, no los duplicó al repetirlo y no volvió a insertarlos después de borrar todas las filas de una tabla existente.

## Configuración y scripts

- Docker Compose 5.6.1 aceptó `compose.yaml`.
- Se comprobó la dependencia de la API respecto del healthcheck PostgreSQL.
- Se verificó la coincidencia de credenciales y el uso de `postgres:5432` desde la API.
- Se comprobó la publicación de PostgreSQL únicamente en loopback del anfitrión y el volumen `/var/lib/postgresql/data`, apropiado para la imagen PostgreSQL 17 utilizada.
- Se comprobó la sintaxis Bash del script nativo y la sintaxis Python de las pruebas.
- Se revisaron y actualizaron las guías para el almacenamiento PostgreSQL.

## Comprobaciones pendientes en los equipos de destino

El anfitrión de pruebas es Ubuntu **24.04.3 LTS**. Ambos proyectos de backend se ejecutaron allí; su nombre no cambia el sistema operativo real que reporta health.

Queda por comprobar:

- Construcción completa y arranque de los contenedores Docker, con PostgreSQL **17** nativo y la API sobre Ubuntu **22.04**.
- Inicialización/persistencia del volumen Docker y permisos del usuario de la imagen.
- Autenticación real por contraseña con PostgreSQL, pooling y arranque simultáneo de ambas APIs sobre PostgreSQL nativo.
- Ejecución visual del cliente y los scripts PowerShell en Windows.
- La red concreta de WSL, del hipervisor y el túnel SSH entre tus máquinas.
- Construcción ARM64.

No se presenta ninguna de esas comprobaciones como aprobada. `tests/docker_integracion.py` está preparado para construir e iniciar un proyecto Compose temporal con PostgreSQL 17, comprobar la imagen Ubuntu 22.04, usuario sin root, CRUD y persistencia tras recrear y tras down/up. Debe ejecutarse en un equipo con Docker Engine funcionando.

## Repetir las pruebas

Prueba Docker, desde `Asignacion4` con Python 3.10 o posterior:

```bash
python3 tests/docker_integracion.py
```

En Windows: `py tests/docker_integracion.py`. Sus recursos temporales llevan un nombre aleatorio distinto del proyecto normal.

La prueba de los dos backends nativos `tests/integracion.py` requiere `TEST_POSTGRES_CONNECTION` apuntando a una base **desechable**, ya creada, cuyo nombre comience con `asignacion4_test_`. Borra sus registros; no se debe apuntar a la base de la demostración. Primero compila ambos proyectos y después configura esa variable de entorno y ejecuta la prueba. No se incluyen credenciales de una base de pruebas real en el proyecto.
